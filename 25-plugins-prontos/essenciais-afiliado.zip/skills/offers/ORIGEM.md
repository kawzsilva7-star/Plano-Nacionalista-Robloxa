Origem: https://github.com/coreyhaines31/marketingskills (pasta skills/offers)
Copiado em 2026-10-27, commit 17772c7
